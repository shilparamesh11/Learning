package Model;

public class DiscussionModel {
private String question;
private int courseId;
private int parentid;
private int postedBy;
public String getQuestion() {
	return question;
}
public void setQuestion(String question) {
	this.question = question;
}
public int getCourseId() {
	return courseId;
}
public void setCourseId(int courseId) {
	this.courseId = courseId;
}
public int getParentid() {
	return parentid;
}
public void setParentid(int parentid) {
	this.parentid = parentid;
}
public int getPostedBy() {
	return postedBy;
}
public void setPostedBy(int postedBy) {
	this.postedBy = postedBy;
}
}
