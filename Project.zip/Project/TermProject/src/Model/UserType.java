package Model;

public enum UserType {INSTRUCTOR, STUDENT};
