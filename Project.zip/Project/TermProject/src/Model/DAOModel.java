package Model;

import DAO.CommonDAO;
import Service.UserService;

public class DAOModel {
	private CommonDAO dao;

	public CommonDAO getDao() {
		return dao;
	}

	public void setDao(CommonDAO dao) {
		this.dao = dao;
	}
}
