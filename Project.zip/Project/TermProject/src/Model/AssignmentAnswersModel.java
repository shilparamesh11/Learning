package Model;

public class AssignmentAnswersModel {
	private int correctAnswerO1=0;
	private int correctAnswerO2=0;
	private int correctAnswerO3=0;
	private int correctAnswerO4=0;
	private int questionId;
	
	public int getCorrectAnswerO1() {
		return correctAnswerO1;
	}
	public void setCorrectAnswerO1(int correctAnswerO1) {
		this.correctAnswerO1 = correctAnswerO1;
	}
	public int getCorrectAnswerO2() {
		return correctAnswerO2;
	}
	public void setCorrectAnswerO2(int correctAnswerO2) {
		this.correctAnswerO2 = correctAnswerO2;
	}
	public int getCorrectAnswerO4() {
		return correctAnswerO4;
	}
	public void setCorrectAnswerO4(int correctAnswerO4) {
		this.correctAnswerO4 = correctAnswerO4;
	}
	public int getCorrectAnswerO3() {
		return correctAnswerO3;
	}
	public void setCorrectAnswerO3(int correctAnswerO3) {
		this.correctAnswerO3 = correctAnswerO3;
	}
	public int getQuestionId() {
		return questionId;
	}
	public void setQuestionId(int questionId) {
		this.questionId = questionId;
	}

}
