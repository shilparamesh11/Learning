package Model;

public class LoginModel {
	private String username;
	private String password;
	private UserType loginUserType;
	private int userId;
	
	public String getUsername(){
		return username;
	}
	
	public void setUsername(String username){
		this.username=username;
	}

	public UserType getLoginUserType() {
		return loginUserType;
	}

	public void setLoginUserType(UserType loginUserType) {
		this.loginUserType = loginUserType;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}
	
}
