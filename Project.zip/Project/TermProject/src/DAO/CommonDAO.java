package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class CommonDAO {
	private String dbuser;
	private String dbpassword;
	private String url;
	private String driver="com.mysql.jdbc.Driver";
	Connection connection;
	Statement stmt;
	
	public CommonDAO(String username,String password,String url){
		this.dbuser=username;
		this.dbpassword=password;
		this.url=url;
	}
	
	public void openConnection()
	{
		try	{
			Class.forName("com.mysql.jdbc.Driver");
			this.connection = DriverManager.getConnection(url,dbuser,dbpassword);
			this.stmt = connection.createStatement();
		} catch(Exception e) {
			e.printStackTrace();}
	}
	
	public void closeConnection()
	{
		try {
			connection.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void InsertRecords(String sql)
	{
		try	{
			stmt.executeUpdate(sql);	
		} catch(Exception e) {
			e.printStackTrace();}
	}
	
	public ResultSet QueryRecords(String sql)
	{
		ResultSet rs=null;
		try	{
			rs=stmt.executeQuery(sql);
		} catch(Exception e) {
			e.printStackTrace();}
		return rs;
	}
}
