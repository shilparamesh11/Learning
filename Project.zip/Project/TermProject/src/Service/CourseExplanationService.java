package Service;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import Model.ExplanationModel;

public class CourseExplanationService{
	private String dbuser;
	private String dbpassword;
	
	public CourseExplanationService(String username,String password){
		this.dbuser=username;
		this.dbpassword=password;
	}
	
	public void addExplanation(ExplanationModel em)
	{
		try	{
			Class.forName("com.mysql.jdbc.Driver");
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/termproject",dbuser,dbpassword);
			//PreparedStatement stmt = connection.prepareStatement("INSERT INTO explanation (courseid, filename, filetype) VALUES ('"+em.getCourseId()+"',?,?);");
			PreparedStatement stmt = connection.prepareStatement("INSERT INTO explanation (courseid, filename, filetype, file) VALUES ('"+em.getCourseId()+"',?,?,?);");
			stmt.setString(1,em.getFileName());
			stmt.setString(2,em.getFileType());
			stmt.setBlob(3,em.getFile());
			stmt.executeUpdate();	
			connection.close();
		} catch(Exception e) {
			e.printStackTrace();}
	}
	
	public ArrayList<ArrayList<String>> getExplanation(int courseId)
	{
		ResultSet rs=null;
		ArrayList<ArrayList<String>> result = new ArrayList<ArrayList<String>>();
		try	{
			Class.forName("com.mysql.jdbc.Driver");
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/termproject",dbuser,dbpassword);
			//PreparedStatement stmt = connection.prepareStatement("SELECT filename, filetype from explanation where courseid='"+courseId+"';");
			PreparedStatement stmt = connection.prepareStatement("SELECT filename, filetype,file from explanation where courseid='"+courseId+"';");
			rs = stmt.executeQuery();
			while(rs.next())
			{
				ArrayList<String> temp = new ArrayList<String>(0);
				temp.add(rs.getString("filename"));
				temp.add(rs.getString("filetype"));
				temp.add(rs.getString("file"));
				result.add(temp);
			}
			connection.close();
		} catch(Exception e) {
			e.printStackTrace();}
		return result;
	}
	
	public InputStream getFileContents(int courseId, String fileName, String fileType)
	{
		ResultSet rs=null;
		InputStream result = null;
		try	{
			Class.forName("com.mysql.jdbc.Driver");
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/termproject",dbuser,dbpassword);
			//PreparedStatement stmt = connection.prepareStatement("SELECT filename, filetype from explanation where courseid='"+courseId+"';");
			String sql = "SELECT file from explanation where courseid='"+courseId+"' AND filename='"+fileName+"' AND filetype='"+fileType+"';";
			PreparedStatement stmt = connection.prepareStatement(sql);
			rs = stmt.executeQuery();
			rs.next();
			result=rs.getBinaryStream("file");
			connection.close();
		} catch(Exception e) {
			e.printStackTrace();}
		return result;
	}
	
}
