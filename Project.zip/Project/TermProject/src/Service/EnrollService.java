package Service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import DAO.CommonDAO;

public class EnrollService{
	String sql;
	ResultSet rs;
	CommonDAO dao;
	public EnrollService(CommonDAO dao){
		this.dao=dao;
	}
	public ArrayList<Integer> getStudentCourseRegistrationDetails(int studentId){
		ArrayList<Integer> result=new ArrayList<Integer>();
		dao.openConnection();
		sql="SELECT COURSEID FROM ENROLLED WHERE USERID='"+studentId+"';";
		rs=dao.QueryRecords(sql);
		try
		{
			while(rs.next())
			{
				result.add(rs.getInt("COURSEID"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		dao.closeConnection();
		return result;
	}
	
	public void enrollStudentToCourse(int studentId, int courseId){
		dao.openConnection();
		sql="INSERT INTO ENROLLED VALUES ("+studentId+", "+courseId+");";
		dao.InsertRecords(sql);
		dao.closeConnection();
	}

}
