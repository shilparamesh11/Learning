package Service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import DAO.CommonDAO;

public class CourseService{	
	UserService userService;
	String sql;
	ResultSet rs;
	CommonDAO dao;
	public CourseService(CommonDAO dao){
		this.dao=dao;
		userService = new UserService(dao);
	}


	public void addCourse(String emailID,String courseName) {
		dao.openConnection();
		int loggedInUserId = userService.getUserIdByEmailId(emailID);
		sql="INSERT INTO COURSE (USERID,COURSENAME) VALUES ('"+loggedInUserId+"','"+courseName+"');";
		dao.InsertRecords(sql);
		dao.closeConnection();
	}
	
	public ArrayList<ArrayList<String>> getInstructorCourses(String emailID){
		int loggedInUserId = userService.getUserIdByEmailId(emailID);
		dao.openConnection();
		ArrayList<ArrayList<String>> courses = new ArrayList<ArrayList<String>>(0);
		sql="SELECT COURSEID,COURSENAME FROM COURSE WHERE USERID ='"+loggedInUserId+"'";	
		rs = dao.QueryRecords(sql);
		try {
			while(rs.next())
			{
				ArrayList<String> temp=new ArrayList<String>(0);
				temp.add(rs.getString("COURSEID"));
				temp.add(rs.getString("COURSENAME"));
				courses.add(temp);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}	
		dao.closeConnection();
		return courses;
	}
	
	public int getInstructorCourseCount(String emailID){
		rs=null;
		int count=0;
		int loggedInUserId = userService.getUserIdByEmailId(emailID);
		dao.openConnection();
		sql = "SELECT COUNT(COURSEID) FROM COURSE WHERE USERID='"+loggedInUserId+"';";
		rs=dao.QueryRecords(sql);
		try {
			rs.next();
			count = rs.getInt("COUNT(COURSEID)");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		dao.closeConnection();
		return count;
	}
	
	public String getCourseName(int courseId){
		String courseName=null;
		dao.openConnection();
		sql="SELECT COURSENAME FROM COURSE WHERE COURSEID='"+courseId+"';";
		rs=dao.QueryRecords(sql);
		try {
			rs.next();
			courseName = rs.getString("COURSENAME");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		dao.closeConnection();
		return courseName;
	}
	
	public ArrayList<String[]> getAllAvailableCourse() {
		ArrayList<String[]> courses=new ArrayList<String[]>();
		dao.openConnection();
		sql="select courseid,coursename from course;";
		rs=dao.QueryRecords(sql);
		try {
			while(rs.next())
			{		
				courses.add(new String[]{rs.getString("courseid"),rs.getString("coursename")});
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		dao.closeConnection();
		return courses;
		
	}
	
	public ArrayList<ArrayList<String>> getStudentCourses(String emailID){
		ArrayList<ArrayList<String>> courses = new ArrayList<ArrayList<String>>(0);
		int loggedInUserId = userService.getUserIdByEmailId(emailID);
		System.out.println(loggedInUserId);
		dao.openConnection();
		sql="SELECT COURSEID FROM ENROLLED WHERE USERID ='"+loggedInUserId+"'";	
		rs = dao.QueryRecords(sql);
		try {
			ArrayList<String> temp = new ArrayList<String>(0);
			while(rs.next())
			{
				temp.add(rs.getString("COURSEID"));
			}
			dao.closeConnection();
			dao.openConnection();
			for(int i=0;i<temp.size();i++)
			{
				ArrayList<String> temp1 = new ArrayList<String>(0);
				sql="SELECT COURSENAME FROM COURSE WHERE COURSEID='"+temp.get(i)+"';";
				rs=dao.QueryRecords(sql);
				rs.next();
				temp1.add(temp.get(i));
				temp1.add(rs.getString("COURSENAME"));
				courses.add(temp1);
			}
			dao.closeConnection();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return courses;
	}
}
