package Service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import DAO.CommonDAO;

public class CourseContentService{
	String sql;
	ResultSet rs;
	CommonDAO dao;
	public CourseContentService(CommonDAO dao){
		this.dao=dao;
	}

	public void addCourseContent(int courseId,String courseContent) {
		dao.openConnection();
		sql="INSERT INTO COURSECONTENT VALUES ('"+courseId+"','"+courseContent+"');";
		dao.InsertRecords(sql);
		dao.closeConnection();
	}
	
	public ArrayList<String> getCoureContents(int courseId) {
		dao.openConnection();
		ArrayList<String> contents = new ArrayList<String>();
		sql="SELECT CONTENT FROM COURSECONTENT WHERE COURSEID="+courseId;
		rs=dao.QueryRecords(sql);
		try {
			while(rs.next())
			contents.add(rs.getString("CONTENT"));
		} catch (SQLException e) {
			e.printStackTrace();
		}
		dao.closeConnection();
		return contents;
	}

}
