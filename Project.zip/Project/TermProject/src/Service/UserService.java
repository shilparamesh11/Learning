package Service;

import java.sql.ResultSet;
import java.sql.SQLException;
import DAO.CommonDAO;

public class UserService{
	String sql;
	ResultSet rs;
	CommonDAO dao;
	public UserService(CommonDAO dao){
		this.dao=dao;
	}
	public int getUserIdByEmailId(String emailId) {
		int instructorId = 0;
		dao.openConnection();
		sql="SELECT USERID FROM USERS WHERE EMAILID = '"+emailId+"';";
		dao.QueryRecords(sql);
		rs=dao.QueryRecords(sql);
		try {
			rs.next();
			instructorId=rs.getInt("USERID");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		//dao.closeConnection();
		return instructorId;
	}
	
	public String getUsernameById(int userId) {
		String result=null;
		dao.openConnection();
		sql="SELECT NAME FROM USERS WHERE userid = '"+userId+"';";
		rs=dao.QueryRecords(sql);
		try {
			rs.next();
			result=rs.getString("name");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		dao.closeConnection();
		return result;
	}
}
