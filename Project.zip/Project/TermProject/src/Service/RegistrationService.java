package Service;

import java.sql.ResultSet;
import DAO.CommonDAO;
import Model.UserRegistrationModel;

public class RegistrationService{
	String sql;
	ResultSet rs;
	CommonDAO dao;
	
	public RegistrationService(CommonDAO dao){
		this.dao=dao;
	}
	public void storeInstructorRecord(UserRegistrationModel registerUserRequest) {
		dao.openConnection();
		sql="INSERT INTO users(name, EMAILID) VALUES('"+registerUserRequest.getName()+"','"+registerUserRequest.getEmailId()+"')";
		dao.InsertRecords(sql);
		dao.closeConnection();
	}

}
