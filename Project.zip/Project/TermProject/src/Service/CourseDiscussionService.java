package Service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import DAO.CommonDAO;
import Model.DiscussionModel;

public class CourseDiscussionService{
	UserService userService;
	String sql;
	ResultSet rs;
	CommonDAO dao;
	public CourseDiscussionService(CommonDAO dao){
		this.dao=dao;
		userService = new UserService(dao);
	}

	public void addDiscussion(DiscussionModel dm) {
		dao.openConnection();
		sql="INSERT INTO DISCUSSION (courseid, comments, parentid, postedby) VALUES ('"+dm.getCourseId()+"','"+dm.getQuestion()+"','"+dm.getParentid()+"','"+dm.getPostedBy()+"');";
		dao.InsertRecords(sql);
		dao.closeConnection();
	}
	
	public ArrayList<ArrayList<String>> getDiscussionQuestions(int courseId) {
		dao.openConnection();
		ArrayList<ArrayList<String>> results = new ArrayList<ArrayList<String>>(0);
		String sql = "SELECT COMMENTID, COMMENTS, POSTEDBY, PARENTID FROM DISCUSSION WHERE parentid=0 AND courseid='"+courseId+"';";
		rs=dao.QueryRecords(sql);
		try {
			while(rs.next())
			{
				ArrayList<String> temp = new ArrayList<String>(0);
				temp.add(rs.getString("commentid"));
				temp.add(rs.getString("PARENTID"));
				temp.add(userService.getUsernameById(Integer.parseInt(rs.getString("POSTEDBY"))));
				temp.add(rs.getString("comments"));
				results.add(temp);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		dao.closeConnection();
		return results;
	}
	public ArrayList<ArrayList<String>> getDiscussionReplies(int courseId) {
		dao.openConnection();
		ArrayList<ArrayList<String>> results = new ArrayList<ArrayList<String>>(0);
		sql="SELECT COMMENTID, COMMENTS, POSTEDBY, PARENTID FROM DISCUSSION WHERE parentid<>0 AND courseid='"+courseId+"';";
		rs=dao.QueryRecords(sql);
		try {
			while(rs.next()){
				ArrayList<String> temp = new ArrayList<String>(0);
				temp.add(rs.getString("commentid"));
				temp.add(rs.getString("PARENTID"));
				temp.add(userService.getUsernameById(Integer.parseInt(rs.getString("POSTEDBY"))));
				temp.add(rs.getString("comments"));
				results.add(temp);
			}
		} catch (SQLException e) {
				e.printStackTrace();}
		dao.closeConnection();
		return results;
	}
}
