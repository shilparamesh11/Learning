package Service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import DAO.CommonDAO;
import Model.AssignmentAnswersModel;
import Model.AssignmentModel;

public class CourseAssignmentService{
	String sql;
	ResultSet rs;
	CommonDAO dao;
	
	public CourseAssignmentService(CommonDAO dao){
		this.dao=dao;
	}
	
	public void addQuestion(AssignmentModel am)
	{
		dao.openConnection();
		sql="INSERT INTO assignmentquestions (courseid, question, option1, option2, option3, option4) VALUES ('"+am.getCourseId()+"','"+am.getQuestion()+"','"+am.getOption1()+"','"+am.getOption2()+"','"+am.getOption3()+"','"+am.getOption4()+"');";
		dao.InsertRecords(sql);
		dao.closeConnection();
	}
	
	public int getQuestionID(AssignmentModel am)
	{
		dao.openConnection();
		int questionId=0;
		String sql = "SELECT QUESTIONID FROM assignmentquestions WHERE QUESTION='"+am.getQuestion()+"' AND OPTION1='"+am.getOption1()+"' AND OPTION2='"+am.getOption2()+"' AND OPTION3='"+am.getOption3()+"' AND OPTION4='"+am.getOption4()+"';";
		rs=dao.QueryRecords(sql);		
		try {
			rs.next();
			questionId=rs.getInt("QUESTIONID");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		dao.closeConnection();
		return questionId;
	}
	
	public void addAnswers(AssignmentAnswersModel am)
	{
		dao.openConnection();
		sql="INSERT INTO assignmentanswers (questionid, option1, option2, option3, option4) VALUES ('"+am.getQuestionId()+"','"+am.getCorrectAnswerO1()+"','"+am.getCorrectAnswerO2()+"','"+am.getCorrectAnswerO3()+"','"+am.getCorrectAnswerO4()+"');";
		dao.InsertRecords(sql);
		dao.closeConnection();
	}
	
	public ArrayList<ArrayList<String>> getQuestionsAnswersForCourseID(int courseId)
	{
		dao.openConnection();
		ArrayList<ArrayList<String>> results=new ArrayList<ArrayList<String>>(0);
		sql="SELECT QUESTION,OPTION1,OPTION2,OPTION3,OPTION4 FROM assignmentquestions WHERE courseid='"+courseId+"';";
		rs=dao.QueryRecords(sql);
		try {
			while(rs.next())
			{
				ArrayList<String> temp=new ArrayList<String>(0);
				temp.add(rs.getString("QUESTION"));
				temp.add(rs.getString("OPTION1"));
				temp.add(rs.getString("OPTION2"));
				temp.add(rs.getString("OPTION3"));
				temp.add(rs.getString("OPTION4"));
				results.add(temp);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		dao.closeConnection();
		return results;
	}
	
	public ArrayList<Integer> getAnswersForQID(int id){
		dao.openConnection();
		ArrayList<Integer> results = new ArrayList<Integer>(0);
		sql="SELECT OPTION1,OPTION2,OPTION3,OPTION4 FROM assignmentanswers WHERE questionid='"+id+"';";
		rs=dao.QueryRecords(sql);
		try {
			while(rs.next())
			{
				results.add(Integer.parseInt(rs.getString("OPTION1")));
				results.add(Integer.parseInt(rs.getString("OPTION2")));
				results.add(Integer.parseInt(rs.getString("OPTION3")));
				results.add(Integer.parseInt(rs.getString("OPTION4")));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		dao.closeConnection();
		return results;
	}
	
	public void storeAssignmentPoints(int id,int questionid,int score){
		dao.openConnection();
		sql="INSERT INTO STUDENTASSIGNMENTPOINTS VALUES ('"+id+"','"+questionid+"','"+score+"');";
		dao.InsertRecords(sql);
		dao.closeConnection();
	}
	
	public Integer getStudentAssignmentPoints(int id, int questionid){
		dao.openConnection();
		Integer results = null;
		sql="SELECT POINTS FROM STUDENTASSIGNMENTPOINTS WHERE questionid='"+questionid+"' AND USERID='"+id+"';";
		rs=dao.QueryRecords(sql);
		try {
				if(rs.next())
				results = (Integer.parseInt(rs.getString("POINTS")));
				else
					results=null;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		dao.closeConnection();
		return results;
	}
	
	public Integer getStudentGradesByCourseId(int id, int courseId){
		dao.openConnection();
		Integer results = null;
		sql="SELECT POINTS FROM GRADES WHERE courseid='"+courseId+"' AND USERID='"+id+"';";
		rs=dao.QueryRecords(sql);
		try {
				if(rs.next())
				results = (Integer.parseInt(rs.getString("POINTS")));
				else
					results=null;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		dao.closeConnection();
		return results;
	}
	
	public void upgradeGradesForCourse(int courseId, int id, int score)
	{ 
		dao.openConnection();
		sql="UPDATE GRADES SET POINTS="+score+" WHERE COURSEID='"+courseId+"' AND USERID='"+id+"';";
		dao.InsertRecords(sql);
		dao.closeConnection();
	}
	
	public void storeStudentGradesForCourse(int courseId, int id, int score)
	{ 
		dao.openConnection();
		sql="INSERT INTO GRADES VALUES ('"+id+"','"+courseId+"','"+score+"');";
		dao.InsertRecords(sql);
		dao.closeConnection();
	}
}
