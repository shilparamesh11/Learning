package Service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import DAO.CommonDAO;

public class GradeCenterService{
	String sql;
	ResultSet rs;
	CommonDAO dao;
	public GradeCenterService(CommonDAO dao){
		this.dao=dao;
	}
	public ArrayList<ArrayList<String>> getCourseGrades(int courseId) {
		ArrayList<ArrayList<String>> results=new ArrayList<ArrayList<String>>(0);
		dao.openConnection();
		sql="SELECT USERID,POINTS FROM GRADES WHERE COURSEID='"+courseId+"';";
		rs=dao.QueryRecords(sql);
		try {
			while(rs.next()){
				ArrayList<String> temp = new ArrayList<String>(0);
				temp.add(rs.getString("USERID"));
				temp.add(rs.getString("POINTS"));
				results.add(temp);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		dao.closeConnection();
		return results;
	}
	
	public ArrayList<ArrayList<String>> sortCourseGrades(ArrayList<Integer> courseIds, String order, String columnName)
	{
		ArrayList<ArrayList<String>> results=new ArrayList<ArrayList<String>>(0);
		dao.openConnection();
		String sql="SELECT U.NAME,C.COURSENAME,G.POINTS FROM COURSE C, USERS U, GRADES G WHERE G.USERID=U.USERID AND C.COURSEID=G.COURSEID";
		if(courseIds.size()!=0)
		{
		sql+=" AND (";
		for(int i=0; i<courseIds.size();i++){
			sql=sql+"C.COURSEID="+courseIds.get(i);
			if(i<courseIds.size()-1){
				sql+=" OR ";}
		}
		sql+=") ORDER BY "+columnName+" "+order+";";
		}
		System.out.println(sql);
		rs=dao.QueryRecords(sql);
		try {
			while(rs.next()){
				ArrayList<String> temp = new ArrayList<String>(0);
				temp.add(rs.getString("U.NAME"));
				temp.add(rs.getString("C.COURSENAME"));
				temp.add(rs.getString("G.POINTS"));
				results.add(temp);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		dao.closeConnection();
	return results;	
	}
	
	public ArrayList<ArrayList<String>> sortStudentCourseGrades(ArrayList<Integer> courseIds, String order, String columnName, String email)
	{
		ArrayList<ArrayList<String>> results=new ArrayList<ArrayList<String>>(0);
		dao.openConnection();
		String sql="SELECT U.NAME,C.COURSENAME,G.POINTS FROM COURSE C, USERS U, GRADES G WHERE G.USERID=U.USERID AND C.COURSEID=G.COURSEID AND U.EMAILID='"+email+"'";
		if(courseIds.size()!=0)
		{
		sql+=" AND (";
		for(int i=0; i<courseIds.size();i++){
			sql=sql+"C.COURSEID="+courseIds.get(i);
			if(i<courseIds.size()-1){
				sql+=" OR ";}
		}
		sql+=") ORDER BY "+columnName+" "+order+";";
		}
		System.out.println(sql);
		rs=dao.QueryRecords(sql);
		try {
			while(rs.next()){
				ArrayList<String> temp = new ArrayList<String>(0);
				temp.add(rs.getString("U.NAME"));
				temp.add(rs.getString("C.COURSENAME"));
				temp.add(rs.getString("G.POINTS"));
				results.add(temp);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		dao.closeConnection();
	return results;	
	}
}
