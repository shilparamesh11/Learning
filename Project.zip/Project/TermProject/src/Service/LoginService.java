package Service;

import java.sql.*;
import DAO.CommonDAO;
import Model.LoginModel;

public class LoginService{
	String sql;
	ResultSet rs;
	CommonDAO dao;
	
	public LoginService(CommonDAO dao){
		this.dao=dao;
	}
	public boolean matchLoginDetails(LoginModel model){
		dao.openConnection();
		sql="SELECT PASSWORD,USERTYPE FROM LOGIN WHERE USERNAME='"+model.getUsername()+"'";
		rs = dao.QueryRecords(sql);
		try {
			if(rs.next())
				if(rs.getString("PASSWORD").equals(model.getPassword()) && rs.getString("USERTYPE").equalsIgnoreCase(model.getLoginUserType().toString())){
					dao.closeConnection();
					return true;
				}
		} catch (SQLException e) {
				e.printStackTrace();}
		dao.closeConnection();
		return false;
	}
	
	public void createLogin(LoginModel model){
		dao.openConnection();
		sql="INSERT INTO LOGIN VALUES('"+model.getUsername()+"','"+model.getPassword()+"','"+model.getLoginUserType().toString()+"')";
		dao.InsertRecords(sql);
		dao.closeConnection();
	}
}
