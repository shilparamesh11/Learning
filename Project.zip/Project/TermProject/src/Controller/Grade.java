package Controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import DAO.CommonDAO;
import Model.DAOModel;
import Model.LoginModel;
import Model.UserType;
import Service.CourseAssignmentService;
import Service.CourseService;
import Service.EnrollService;
import Service.GradeCenterService;
import Service.UserService;

import java.util.ArrayList;

@WebServlet("/Grade")
public class Grade extends HttpServlet {
	private static final long serialVersionUID = 1L;
	UserService userService;
	CourseService courseService;
	GradeCenterService gradeCenterService;
    public Grade() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession s=request.getSession();
		userService=new UserService((CommonDAO) ((DAOModel) s.getAttribute("dao")).getDao());
		courseService=new CourseService((CommonDAO) ((DAOModel) s.getAttribute("dao")).getDao());
		gradeCenterService = new GradeCenterService((CommonDAO) ((DAOModel) s.getAttribute("dao")).getDao());
		
		if(request.getRequestURI().endsWith("sortaction"))
		{
			String sortOrder = request.getParameter("sortOrder");
			String sortColumn = request.getParameter("columnName");
			HttpSession session = request.getSession();
			LoginModel lm=(LoginModel) session.getAttribute("LoginModel");
			String emailId=lm.getUsername();
			ArrayList<ArrayList<String>> results = viewGrades(sortOrder,sortColumn,emailId,lm.getLoginUserType());
			String courseName=request.getParameter("courseName");
			request.setAttribute("results", results);
			request.setAttribute("courseName", courseName);
			request.getRequestDispatcher("GradeCenter.jsp").forward(request, response);
		}
		else if(request.getRequestURI().endsWith("viewStudentGradeCenter")) {
			String sortOrder = "Ascending";
			String sortColumn = "Course";
			HttpSession session = request.getSession();
			LoginModel lm=(LoginModel) session.getAttribute("LoginModel");
			String emailId=lm.getUsername();
			ArrayList<ArrayList<String>> results = viewGrades(sortOrder,sortColumn,emailId,lm.getLoginUserType());
			for(int o=0;o<results.size();o++){
				System.out.println(results.get(0));
			}
			String courseName=request.getParameter("courseName");
			request.setAttribute("results", results);
			request.setAttribute("courseName", courseName);
			request.getRequestDispatcher("GradeCenter.jsp").forward(request, response);
		}
		else
		{
			String sortOrder = "Ascending";
			String sortColumn = "Student Name";
			HttpSession session = request.getSession();
			LoginModel lm=(LoginModel) session.getAttribute("LoginModel");
			String emailId=lm.getUsername();
			ArrayList<ArrayList<String>> results = viewGrades(sortOrder,sortColumn,emailId,lm.getLoginUserType());
			String courseName=request.getParameter("courseName");
			request.setAttribute("results", results);
			request.setAttribute("courseName", courseName);
			request.getRequestDispatcher("GradeCenter.jsp").forward(request, response);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	
	protected ArrayList<ArrayList<String>> viewGrades(String sortOrder,String sortColumn, String emailId, UserType userType){
		ArrayList<ArrayList<String>> results = new ArrayList<ArrayList<String>>(0);
		ArrayList<ArrayList<String>> courses=new ArrayList<ArrayList<String>>(0);
		if (userType==UserType.INSTRUCTOR){
			courses = courseService.getInstructorCourses(emailId);
		}
		else
		{
			courses = courseService.getStudentCourses(emailId);
		}
		ArrayList<Integer> courseIds=new ArrayList<Integer>(0);
		for(int i=0;i<courses.size();i++)
		{
			courseIds.add(Integer.parseInt(courses.get(i).get(0)));
		}
		String order= null;
		String columnName=null;
		if(sortOrder.equalsIgnoreCase("Descending"))
			order="DESC";
		else
			order="ASC";
		if(sortColumn.equalsIgnoreCase("Grade points"))
			columnName="G.POINTS";
		else if(sortColumn.equalsIgnoreCase("Course"))
			columnName="C.COURSENAME";
		else
			columnName="U.NAME";
		if(userType==UserType.INSTRUCTOR)
			results = gradeCenterService.sortCourseGrades(courseIds, order, columnName);
		else
			results = gradeCenterService.sortStudentCourseGrades(courseIds, order, columnName, emailId);
		return results;
	}

}
