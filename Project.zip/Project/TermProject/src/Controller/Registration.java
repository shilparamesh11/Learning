package Controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import DAO.CommonDAO;
import Model.DAOModel;
import Model.LoginModel;
import Model.UserRegistrationModel;
import Model.UserType;
import Service.CourseService;
import Service.GradeCenterService;
import Service.LoginService;
import Service.RegistrationService;
import Service.UserService;

/**
 * Servlet implementation class InstructorRegistrationServlet
 */
@WebServlet("/Registration")
public class Registration extends HttpServlet {
	private static final long serialVersionUID = 1L;
	LoginService loginService;
	RegistrationService registrationService;
       
    public Registration() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession s=request.getSession();
		loginService=new LoginService((CommonDAO) ((DAOModel) s.getAttribute("dao")).getDao());
		registrationService=new RegistrationService((CommonDAO) ((DAOModel) s.getAttribute("dao")).getDao());
		
		String name = request.getParameter("Name");
		String emailId = request.getParameter("emailId");
		String password = request.getParameter("password");
		String confirmPassword = request.getParameter("confirmPassword");
		String register = request.getParameter("register");
		if(name.isEmpty() || emailId.isEmpty() || password.isEmpty() || confirmPassword.isEmpty())
		{
			request.setAttribute("message", "Name, EmailID, password and confirm password fields cannot be blank ...");
			request.getRequestDispatcher("Registration.jsp").forward(request, response);
		}
		else
		{
			if(password.equals(confirmPassword))
			{
				LoginModel registerLogin = new LoginModel();
				registerLogin.setUsername(emailId);
				registerLogin.setPassword(confirmPassword);
				if(register.equalsIgnoreCase("Student"))
					registerLogin.setLoginUserType(UserType.STUDENT);
				else
					registerLogin.setLoginUserType(UserType.INSTRUCTOR);
				loginService.createLogin(registerLogin);
				
				UserRegistrationModel registerUserRequest = new UserRegistrationModel();
				registerUserRequest.setName(name);
				registerUserRequest.setEmailId(emailId);
				if(register.equalsIgnoreCase("Student"))
					registerLogin.setLoginUserType(UserType.STUDENT);
				else
					registerLogin.setLoginUserType(UserType.INSTRUCTOR);
				registrationService.storeInstructorRecord(registerUserRequest);
				
				request.setAttribute("message", "Registration successful. Please login...");
				request.getRequestDispatcher("Login.jsp").forward(request, response);
			}
			else {
				request.setAttribute("message", "Password and confirm password fields does not match ...");
				request.getRequestDispatcher("Registration.jsp").forward(request, response);
			}
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
