package Controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import Model.ExplanationModel;
import Service.CourseExplanationService;

/**
 * Servlet implementation class CourseExplanation
 */
@MultipartConfig
@WebServlet("/CourseExplanation")
public class CourseExplanation extends HttpServlet {
	private static final long serialVersionUID = 1L;
	final String filePath=System.getProperty("user.dir")+File.separator+"Project"+File.separator+"TermProject"+File.separator+"WebContent"+File.separator;

    public CourseExplanation() {
        super();
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		if(request.getRequestURI().endsWith("ViewExplanation"))
		{
			int courseId=Integer.parseInt(request.getParameter("courseId"));
			request.setAttribute("courseId", courseId);
			ArrayList<ArrayList<String>> getdata = new CourseExplanationService("root","test123").getExplanation(courseId);
			request.setAttribute("results",getdata);
			String courseName=request.getParameter("courseName");
			request.setAttribute("courseName", courseName);
			request.getRequestDispatcher("ViewMaterials.jsp").forward(request, response);
		} else if(request.getRequestURI().endsWith("AddExplanation")){
			int courseId=Integer.parseInt(request.getParameter("courseId"));
			request.setAttribute("courseId", courseId);
			String courseName=request.getParameter("courseName");
			request.setAttribute("courseName", courseName);
			request.getRequestDispatcher("UploadMaterials.jsp").forward(request, response);
		} else if(request.getRequestURI().endsWith("uploadExplanationSubmit")){
			int courseId = Integer.parseInt(request.getParameter("courseId"));
			String nameOfFile=request.getParameter("nameOfFile");
			String typeOfFile=request.getParameter("typeOfFile");
			Part file =  request.getPart("explanation");
			if(nameOfFile.isEmpty()||typeOfFile.isEmpty())
			{
				request.setAttribute("message", "File name, type and file cannot be empty..");
			} else {
			InputStream inputStream = file.getInputStream();
			ExplanationModel em=new ExplanationModel();
			em.setCourseId(courseId);
			em.setFileName(nameOfFile);
			em.setFileType(typeOfFile);
			em.setFile(inputStream);
			new CourseExplanationService("root","test123").addExplanation(em);
			request.setAttribute("message","Your file was successfully uploaded .. ");
			}
			request.setAttribute("courseId", courseId);
			String courseName=request.getParameter("courseName");
			request.setAttribute("courseName", courseName);
			request.getRequestDispatcher("UploadMaterials.jsp").forward(request, response);
		} else if(request.getRequestURI().endsWith("view")){
			String fileName=request.getParameter("fileName");
			String fileType=request.getParameter("fileType");
			System.out.println(fileName+""+fileType);
			int courseId=Integer.parseInt(request.getParameter("courseId"));
			CourseExplanationService ce=new CourseExplanationService("root","test123");
			OutputStream outputStream = response.getOutputStream();
			int read = 0;
			byte[] bytes = new byte[1024];
			InputStream inputStream = ce.getFileContents(courseId,fileName,fileType);
			while ((read = inputStream.read(bytes)) != -1) {
				outputStream.write(bytes, 0, read); System.out.println(read);}
			outputStream.flush();
			outputStream.close();
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
