package Controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import DAO.CommonDAO;
import Model.DAOModel;
import Model.DiscussionModel;
import Model.LoginModel;
import Service.CourseContentService;
import Service.CourseDiscussionService;
import Service.CourseService;
import Service.UserService;

/**
 * Servlet implementation class Discussion
 */
@WebServlet("/Discussion")
public class Discussion extends HttpServlet {
	private static final long serialVersionUID = 1L;
	CourseDiscussionService courseDiscussionService;
	UserService userService;
	
    public Discussion() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession s=request.getSession();
		courseDiscussionService = new CourseDiscussionService((CommonDAO) ((DAOModel) s.getAttribute("dao")).getDao());
		userService=new UserService((CommonDAO) ((DAOModel) s.getAttribute("dao")).getDao());
		
		if(request.getRequestURI().endsWith("viewDiscussion"))
		{
			int courseId=Integer.parseInt(request.getParameter("courseId"));
			request.setAttribute("courseId", courseId);
			ArrayList<ArrayList<String>> questions =  new ArrayList<ArrayList<String>>(0);
			questions=courseDiscussionService.getDiscussionQuestions(courseId);
			request.setAttribute("questions", questions);
			ArrayList<ArrayList<String>> replies =  new ArrayList<ArrayList<String>>(0);
			replies=courseDiscussionService.getDiscussionReplies(courseId);
			request.setAttribute("replies", replies);
			String courseName=request.getParameter("courseName");
			request.setAttribute("courseName", courseName);
			request.getRequestDispatcher("Discussion.jsp").forward(request, response);
		}
		else if(request.getRequestURI().endsWith("postQuestion"))
		{
		String disquestion = request.getParameter("disquestion");
		int courseId=Integer.parseInt(request.getParameter("courseId"));
		if(disquestion.isEmpty())
		{
			request.setAttribute("message", "Question cannot be empty");
		} else {
		DiscussionModel dm = new DiscussionModel();
		HttpSession session = request.getSession();
		LoginModel lm=(LoginModel) session.getAttribute("LoginModel");
		dm.setPostedBy(userService.getUserIdByEmailId(lm.getUsername()));
		dm.setQuestion(disquestion);
		dm.setCourseId(courseId);
		dm.setParentid(0);
		courseDiscussionService.addDiscussion(dm);
		}
		courseId=Integer.parseInt(request.getParameter("courseId"));
		ArrayList<ArrayList<String>> questions =  new ArrayList<ArrayList<String>>(0);
		questions=courseDiscussionService.getDiscussionQuestions(courseId);
		request.setAttribute("questions", questions);
		ArrayList<ArrayList<String>> replies =  new ArrayList<ArrayList<String>>(0);
		replies=courseDiscussionService.getDiscussionReplies(courseId);
		request.setAttribute("replies", replies);		

		String courseName=request.getParameter("courseName");
		request.setAttribute("courseId", courseId);
		request.setAttribute("courseName", courseName);
		request.getRequestDispatcher("Discussion.jsp").forward(request, response);
		}
		else if(request.getRequestURI().endsWith("postReply"))
		{
			int questionId = Integer.parseInt(request.getParameter("questionId"));
			String disreply=request.getParameter("disreply");
			int courseId=Integer.parseInt(request.getParameter("courseId"));
			if(disreply.isEmpty())
			{
				request.setAttribute("message", "Replies cannot be empty");
			} else {
			DiscussionModel dm = new DiscussionModel();
			HttpSession session = request.getSession();
			LoginModel lm=(LoginModel) session.getAttribute("LoginModel");
			dm.setPostedBy(userService.getUserIdByEmailId(lm.getUsername()));
			dm.setQuestion(disreply);
			dm.setCourseId(courseId);
			dm.setParentid(questionId);
			courseDiscussionService.addDiscussion(dm);
			}
			ArrayList<ArrayList<String>> questions =  new ArrayList<ArrayList<String>>(0);
			questions=courseDiscussionService.getDiscussionQuestions(courseId);
			request.setAttribute("questions", questions);
			ArrayList<ArrayList<String>> replies =  new ArrayList<ArrayList<String>>(0);
			replies=courseDiscussionService.getDiscussionReplies(courseId);
			request.setAttribute("replies", replies);	
			String courseName=request.getParameter("courseName");
			request.setAttribute("courseName", courseName);
			request.setAttribute("courseId", courseId);
			request.getRequestDispatcher("Discussion.jsp").forward(request, response);
		}
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
