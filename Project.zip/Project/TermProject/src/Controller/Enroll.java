package Controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import DAO.CommonDAO;
import Model.DAOModel;
import Model.LoginModel;
import Service.CourseAssignmentService;
import Service.CourseDiscussionService;
import Service.CourseService;
import Service.EnrollService;
import Service.UserService;

@WebServlet("/Enroll")
public class Enroll extends HttpServlet {
	private static final long serialVersionUID = 1L;
	CourseService courseService;
	EnrollService enrollService;
	CourseAssignmentService courseAssignmentService;
    public Enroll() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession s=request.getSession();
		courseService = new CourseService((CommonDAO) ((DAOModel) s.getAttribute("dao")).getDao());
		enrollService = new EnrollService((CommonDAO) ((DAOModel) s.getAttribute("dao")).getDao());
		courseAssignmentService = new CourseAssignmentService((CommonDAO) ((DAOModel) s.getAttribute("dao")).getDao());
		
		String requestedUrl = request.getRequestURI();
		if(requestedUrl.endsWith("enrollClass")) {
			int courseId = Integer.parseInt(request.getParameter("courseId"));
			String courseName = request.getParameter("courseName");
			request.setAttribute("courseName", courseName);
			request.setAttribute("courseId", courseId);
			HttpSession session =  request.getSession();
			LoginModel loginModel = (LoginModel) session.getAttribute("LoginModel");
			enrollService.enrollStudentToCourse(loginModel.getUserId(),courseId);
			ArrayList<Integer> enrolledCourseList = enrollService.getStudentCourseRegistrationDetails(loginModel.getUserId());
			courseAssignmentService.storeStudentGradesForCourse(courseId, loginModel.getUserId(), -1);
			ArrayList<String[]> courseList=courseService.getAllAvailableCourse();
			request.setAttribute("StudentCourseList", courseList);
			request.setAttribute("enrolledCourseList", enrolledCourseList);
			request.getRequestDispatcher("StudentCourseList.jsp").forward(request, response);
		}
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
