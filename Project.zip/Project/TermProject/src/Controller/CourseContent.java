package Controller;

import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import DAO.CommonDAO;
import Model.DAOModel;
import Model.LoginModel;
import Service.CourseAssignmentService;
import Service.CourseContentService;
import Service.CourseService;

@WebServlet("/CourseContent")
public class CourseContent extends HttpServlet {
	private static final long serialVersionUID = 1L;
	CourseContentService courseContentService;
	CourseService courseService;

    public CourseContent() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession s=request.getSession();
		courseContentService = new CourseContentService((CommonDAO) ((DAOModel) s.getAttribute("dao")).getDao());
		courseService=new CourseService((CommonDAO) ((DAOModel) s.getAttribute("dao")).getDao());
		
		String reqUrl=request.getRequestURI();
		if(reqUrl.endsWith("courseSubmit"))
			requestInstructorCourse(request,response);
		else if(reqUrl.contains("courseContentSubmit"))
			requestAddCourseContent(request,response);
		else if(reqUrl.contains("ViewContent")||reqUrl.contains("viewCourseContent"))
		{
			int courseId = Integer.parseInt(request.getParameter("courseId"));
			String courseName = request.getParameter("courseName");
			String backButtonHelper = request.getParameter("backButtonHelper");
			request.setAttribute("courseName", courseName);
			request.setAttribute("courseId", courseId);
			request.setAttribute("backButtonHelper", backButtonHelper);
			ArrayList<String> contents=courseContentService.getCoureContents(courseId);
			request.setAttribute("contents", contents);
			request.getRequestDispatcher("ViewContent.jsp").forward(request, response);
		}
		else if(reqUrl.contains("AddContent"))
		{
			int courseId = Integer.parseInt(request.getParameter("courseId"));
			request.setAttribute("courseId", courseId);
			String courseName = request.getParameter("courseName");
			request.setAttribute("courseName", courseName);
			request.getRequestDispatcher("CreateContent.jsp").forward(request, response);
		} 
		else if(reqUrl.contains("viewClass"))
		{
			int courseId = Integer.parseInt(request.getParameter("courseId"));
			request.setAttribute("courseId", courseId);
			String courseName = request.getParameter("courseName");
			request.setAttribute("courseName", courseName);
			request.getRequestDispatcher("StudentCourse.jsp").forward(request, response);
		}
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

	private void requestAddCourseContent(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int courseId = Integer.parseInt(request.getParameter("courseId"));
		String courseName = request.getParameter("courseName");
		String courseContent = request.getParameter("newcourseContent");
		if (courseContent.isEmpty())
		{
			request.setAttribute("message", "Course explanation cannot be empty");
		} else {
		LoginModel loggedInUser=(LoginModel) request.getSession().getAttribute("LoginModel");
		courseContentService.addCourseContent(courseId,courseContent);
		request.setAttribute("message","Your content was successfully added..");
		}
		request.setAttribute("courseName", courseName);
		request.setAttribute("courseId", courseId);
		requestViewCourseContent(request, response);
		request.getRequestDispatcher("CreateContent.jsp").forward(request, response);
		
	}
	
	private void requestInstructorCourse(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int courseId=Integer.parseInt(request.getParameter("gotoValue"));
		request.setAttribute("courseName", courseService.getCourseName(courseId));
		request.setAttribute("courseId", courseId);
		ArrayList<String> contents=courseContentService.getCoureContents(courseId);
		request.setAttribute("contents", contents);
		request.getRequestDispatcher("Course.jsp").forward(request, response);
	}
	
	private void requestViewCourseContent(HttpServletRequest request, HttpServletResponse response) {
		int courseId = Integer.parseInt(request.getParameter("courseId"));
		String courseName=request.getParameter("courseName");
		request.setAttribute("courseName", courseName);
		ArrayList<String> contents=courseContentService.getCoureContents(courseId);
		request.setAttribute("contents", contents);
	}
}
