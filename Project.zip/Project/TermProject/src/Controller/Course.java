package Controller;

import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import DAO.CommonDAO;
import Model.DAOModel;
import Model.LoginModel;
import Service.CourseService;

@WebServlet("/Course")
public class Course extends HttpServlet {
	private static final long serialVersionUID = 1L;
	CourseService courseService;

    public Course() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {		
		String reqUrl=request.getRequestURI();
		HttpSession s = request.getSession();
		courseService = new CourseService((CommonDAO) ((DAOModel) s.getAttribute("dao")).getDao());
		
		if(reqUrl.endsWith("AddCourseSubmit"))
			requestAddCourse(request,response);	
		else if(reqUrl.endsWith("RetrieveStudentCourses"))
			viewStudentCourses(request,response);
	}
	
	public void viewStudentCourses(HttpServletRequest request, HttpServletResponse response) {
		HttpSession s = request.getSession();
		courseService = new CourseService((CommonDAO) ((DAOModel) s.getAttribute("dao")).getDao());
		ArrayList<String[]> courseList=courseService.getAllAvailableCourse();
		request.setAttribute("StudentCourseList", courseList);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	
	private void requestAddCourse(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{	
		HttpSession s = request.getSession();
		courseService = new CourseService((CommonDAO) ((DAOModel) s.getAttribute("dao")).getDao());
		String courseName=request.getParameter("courseName");
		if(courseName.isEmpty())
		{
			request.setAttribute("error", "Course Name cannot be blank..");
			requestViewCourse(request, response);
			request.getRequestDispatcher("Dashboard.jsp").forward(request,response);
		} else {
			LoginModel loggedInUser=(LoginModel) request.getSession().getAttribute("LoginModel");
			int instructorCourseCount = courseService.getInstructorCourseCount(loggedInUser.getUsername());
			if(instructorCourseCount>=3)
			{
				request.setAttribute("error", "Cannot add more than three courses...");
				requestViewCourse(request, response);
				request.getRequestDispatcher("Dashboard.jsp").forward(request,response);
			}
			else
			{
				courseService.addCourse(loggedInUser.getUsername(),courseName);
				requestViewCourse(request, response);
				request.getRequestDispatcher("Dashboard.jsp").forward(request,response);
			}
		}
	}
	
	public void requestViewCourse(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		HttpSession s = request.getSession();
		courseService = new CourseService((CommonDAO) ((DAOModel) s.getAttribute("dao")).getDao());
		LoginModel loggedInUser=(LoginModel) request.getSession().getAttribute("LoginModel");
		ArrayList<ArrayList<String>> courses=courseService.getInstructorCourses(loggedInUser.getUsername());
		request.setAttribute("courses", courses);
		request.getRequestDispatcher("Dashboard.jsp").forward(request,response);
	}

}
