package Controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import DAO.CommonDAO;
import Model.AssignmentAnswersModel;
import Model.AssignmentModel;
import Model.DAOModel;
import Model.LoginModel;
import Model.UserType;
import Service.CourseAssignmentService;

@WebServlet("/CourseAssignment")
public class CourseAssignment extends HttpServlet {
	private static final long serialVersionUID = 1L;
	CourseAssignmentService courseAssignmentService;
	AssignmentModel am = new AssignmentModel();
	
    public CourseAssignment() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession s=request.getSession();
		courseAssignmentService = new CourseAssignmentService((CommonDAO) ((DAOModel) s.getAttribute("dao")).getDao());
		if(request.getRequestURI().endsWith("ViewAssignment"))
		{
			int courseId=Integer.parseInt(request.getParameter("courseId"));	
			ArrayList<ArrayList<String>> getQuestions = courseAssignmentService.getQuestionsAnswersForCourseID(courseId);
			HttpSession session=request.getSession();
			LoginModel loginModel=(LoginModel) session.getAttribute("LoginModel");
			for(int j=0;j<getQuestions.size();j++){
				am.setQuestion(getQuestions.get(j).get(0));
				am.setOption1(getQuestions.get(j).get(1));
				am.setOption2(getQuestions.get(j).get(2));
				am.setOption3(getQuestions.get(j).get(3));
				am.setOption4(getQuestions.get(j).get(4));
				int questiontempid=courseAssignmentService.getQuestionID(am);
				Integer scoretemp=courseAssignmentService.getStudentAssignmentPoints(loginModel.getUserId(), questiontempid);
				request.setAttribute(getQuestions.get(j).get(0)+"-score", scoretemp);
			}
			request.setAttribute("getquestions", getQuestions);
			request.setAttribute("courseId", courseId);
			String courseName=request.getParameter("courseName");
			request.setAttribute("courseName", courseName);
			if(loginModel.getLoginUserType()==UserType.STUDENT)
				request.getRequestDispatcher("StudentAssignment.jsp").forward(request, response);
			else
				request.getRequestDispatcher("ViewAssignment.jsp").forward(request, response);
		}
		else if(request.getRequestURI().endsWith("AddAssignment"))
		{
			int courseId=Integer.parseInt(request.getParameter("courseId"));
			request.setAttribute("courseId", courseId);
			String courseName=request.getParameter("courseName");
			request.setAttribute("courseName", courseName);
			request.getRequestDispatcher("CreateAssignment.jsp").forward(request, response);
		}
		else if(request.getRequestURI().endsWith("SubmitAnswer")){
			int courseId=Integer.parseInt(request.getParameter("courseId"));
			request.setAttribute("courseId", courseId);
			String courseName=request.getParameter("courseName");
			request.setAttribute("courseName", courseName);
			String[] studentAnswers=request.getParameterValues(""+request.getParameter("question"));
			am.setQuestion(request.getParameter("question"));
			am.setOption1(request.getParameter("option1"));
			am.setOption2(request.getParameter("option2"));
			am.setOption3(request.getParameter("option3"));
			am.setOption4(request.getParameter("option4"));
			int questionId = courseAssignmentService.getQuestionID(am);
			ArrayList<Integer> answers = courseAssignmentService.getAnswersForQID(questionId);
			HttpSession session=request.getSession();
			LoginModel loginModel=(LoginModel) session.getAttribute("LoginModel");
			if(studentAnswers==null)
			{
				request.setAttribute("message", "Answer selections cannot be empty");
			}
			else{
			ArrayList<Integer> sAnswers=new ArrayList<Integer>(0);
			int score=10;
			for(int k=0;k<studentAnswers.length;k++){
				sAnswers.add(Integer.parseInt(studentAnswers[k]));
			}
			Boolean bflag;
			for(int l=0;l<answers.size();l++){
			bflag=false;
			if(answers.get(l)==1){
				for(int m:sAnswers){
					if(m==(l+1)){
					bflag=true;
					break;}}
			if(bflag!=true){
				score=0;
				break;}}}
			
			Integer grade=courseAssignmentService.getStudentGradesByCourseId(loginModel.getUserId(),courseId);
			
			if(grade==-1)
				courseAssignmentService.upgradeGradesForCourse(courseId, loginModel.getUserId(), score);
			else
				courseAssignmentService.upgradeGradesForCourse(courseId, loginModel.getUserId(), grade+score);

			
			courseAssignmentService.storeAssignmentPoints(loginModel.getUserId(), questionId, score);}
			ArrayList<ArrayList<String>> getQuestions = courseAssignmentService.getQuestionsAnswersForCourseID(courseId);
			for(int j=0;j<getQuestions.size();j++){
				am.setQuestion(getQuestions.get(j).get(0));
				am.setOption1(getQuestions.get(j).get(1));
				am.setOption2(getQuestions.get(j).get(2));
				am.setOption3(getQuestions.get(j).get(3));
				am.setOption4(getQuestions.get(j).get(4));
				int questiontempid=courseAssignmentService.getQuestionID(am);
				Integer scoretemp=courseAssignmentService.getStudentAssignmentPoints(loginModel.getUserId(), questiontempid);
				request.setAttribute(getQuestions.get(j).get(0)+"-score", scoretemp);
			}
			request.setAttribute("getquestions", getQuestions);
			request.getRequestDispatcher("StudentAssignment.jsp").forward(request, response);
		}
		else
		{
		String question=request.getParameter("Question");
		String option1=request.getParameter("option1");
		String option2=request.getParameter("option2");
		String option3=request.getParameter("option3");
		String option4=request.getParameter("option4");
		int courseId=Integer.parseInt(request.getParameter("courseId"));
		String courseName=request.getParameter("courseName");
		String[] correctOptions=request.getParameterValues("correctOptions");
		
		if(question.isEmpty()||option1.isEmpty()||option2.isEmpty()||option3.isEmpty()||option4.isEmpty()||correctOptions.length==0){
			request.setAttribute("message", "Questions, options and correct answers cannot be empty");
		}
		else {
		AssignmentModel am = new AssignmentModel();
		am.setCourseId(courseId);
		am.setQuestion(question);
		am.setOption1(option1);
		am.setOption2(option2);
		am.setOption3(option3);
		am.setOption4(option4);
		courseAssignmentService.addQuestion(am);
		
		
		AssignmentAnswersModel aam=new AssignmentAnswersModel();
		aam.setQuestionId(courseAssignmentService.getQuestionID(am));
		for(int i=0;i<correctOptions.length;i++)
		{
			if(correctOptions[i].equalsIgnoreCase("Option1"))
				aam.setCorrectAnswerO1(1);
			else if(correctOptions[i].equalsIgnoreCase("Option2"))
				aam.setCorrectAnswerO2(1);
			else if(correctOptions[i].equalsIgnoreCase("Option3"))
				aam.setCorrectAnswerO3(1);
			else if(correctOptions[i].equalsIgnoreCase("Option4"))
				aam.setCorrectAnswerO4(1);
		}
		courseAssignmentService.addAnswers(aam);
		ArrayList<ArrayList<String>> getQuestions = courseAssignmentService.getQuestionsAnswersForCourseID(courseId);
		request.setAttribute("getquestions", getQuestions);
		request.setAttribute("message","Your assignment was successfully added .. ");
		}
		request.setAttribute("courseId", courseId);
		request.setAttribute("courseName", courseName);
		request.getRequestDispatcher("CreateAssignment.jsp").forward(request, response);
	}
}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
