package Controller;


import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import DAO.CommonDAO;
import Model.DAOModel;
import Model.LoginModel;
import Model.UserType;
import Service.EnrollService;
import Service.LoginService;
import Service.UserService;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/Login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
	LoginService loginService;
	Course course = new Course();
	EnrollService enrollService;
	DAOModel daoModel=new DAOModel();

    public Login() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		CommonDAO dao = new CommonDAO("root","test123","jdbc:mysql://localhost/termproject");
		daoModel.setDao(dao);
		HttpSession newSession = request.getSession();
		newSession.setAttribute("dao", daoModel);
		loginService=new LoginService(dao);
		UserService userService = new UserService(dao);
		enrollService = new EnrollService(dao);
		
		String url = request.getRequestURI();
		
		if(url.endsWith("RegisterUser"))
		{
			request.getRequestDispatcher("Registration.jsp").forward(request, response);
		}
		else
		{
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String userType = request.getParameter("userType");
		if(username.isEmpty() || password.isEmpty())
		{
			request.setAttribute("message", "Username, password and User fields cannot be blank ...");
			request.getRequestDispatcher("Login.jsp").forward(request, response);
		} else {
			LoginModel model = new LoginModel();
			model.setUsername(username);
			model.setPassword(password);
			System.out.println(username);
			model.setUserId(userService.getUserIdByEmailId(username));
			if(userType.equalsIgnoreCase("Instructor"))
				model.setLoginUserType(UserType.INSTRUCTOR);
			else if (userType.equalsIgnoreCase("Student"))
				model.setLoginUserType(UserType.STUDENT);
			if(loginService.matchLoginDetails(model))
			{
				
				newSession.setAttribute("LoginModel", model);
				if(userType.equalsIgnoreCase("Student"))
				{
					ArrayList<Integer> enrolledCourseList = enrollService.getStudentCourseRegistrationDetails(userService.getUserIdByEmailId(username));
					course.viewStudentCourses(request, response);
					request.setAttribute("enrolledCourseList", enrolledCourseList);
					request.getRequestDispatcher("StudentCourseList.jsp").forward(request, response);
				} else {
				new Course().requestViewCourse(request, response);
				request.getRequestDispatcher("Dashboard.jsp").forward(request, response); }
			} else {
				request.setAttribute("message", "Invalid username or password");
				request.getRequestDispatcher("Login.jsp").forward(request, response);
			}
		}}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
