package Controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import DAO.CommonDAO;
import Model.DAOModel;
import Model.LoginModel;
import Model.UserType;
import Service.EnrollService;
import Service.UserService;

/**
 * Servlet implementation class Back
 */
@WebServlet("/Back")
public class Back extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Course course = new Course();
	EnrollService enrollService;
	UserService userService;
	
    public Back() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession s=request.getSession();
		
		enrollService=new EnrollService((CommonDAO) ((DAOModel) s.getAttribute("dao")).getDao());
		userService=new UserService((CommonDAO) ((DAOModel) s.getAttribute("dao")).getDao());
		
		String url = request.getRequestURI();
		LoginModel lm=(LoginModel) s.getAttribute("LoginModel");
		UserType userType=lm.getLoginUserType();
		if(url.endsWith("backRegistration"))
		{
			request.getRequestDispatcher("Login.jsp").forward(request, response);
		} else if(url.endsWith("backCourse"))
		{
			if(userType==UserType.STUDENT){
				ArrayList<Integer> enrolledCourseList = enrollService.getStudentCourseRegistrationDetails(userService.getUserIdByEmailId(lm.getUsername()));
				course.viewStudentCourses(request, response);
				request.setAttribute("enrolledCourseList", enrolledCourseList);
				request.getRequestDispatcher("StudentCourseList.jsp").forward(request, response);
			} else {
			new Course().requestViewCourse(request, response);
			request.getRequestDispatcher("Dashboard.jsp").forward(request, response);
			}
		} else
		{
			int courseId = Integer.parseInt(request.getParameter("courseId"));
			String courseName = request.getParameter("courseName");
			request.setAttribute("courseName", courseName);
			request.setAttribute("courseId", courseId);
			if(userType==UserType.STUDENT){
				request.getRequestDispatcher("StudentCourse.jsp").forward(request, response);
			} else {
			request.getRequestDispatcher("Course.jsp").forward(request, response);}
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
